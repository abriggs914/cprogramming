# C Programming CS 2263
This repository is for practicing with Github repositories. 
I have a file in this repository that I will upload to Stepik at the end of this exercise.
Only the students who have their Stepik ID in this file would get the full mark for this exercise.

# Procedure
1. Create a Github account (if you already have an account, just login)
2. Fork this repository.
3. Clone your fork locally for editing or edit it on Github directly
4. Edit the file: scores.csv and add the following line to the end of the file:

    stepikID, 100, Full Name
  
 5. Commit the file to your local repository
 6. Create a pull-request on your file to be updated in this repository. I will need to approve this later.
 7. Make sure you receive a notification that your pull-request was accepted.
 8. If you encountered any issues, please create an "Issue" in Github.
 
 Thank you and good luck!
